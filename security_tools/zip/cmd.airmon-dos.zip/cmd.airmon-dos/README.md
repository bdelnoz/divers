# Script Airmon-DOS

## Description
Ce script permet de scanner les réseaux Wi-Fi et d'effectuer une attaque DOS réelle ciblée.
Les exclusions (MAC et BSSID) sont gérées via un fichier externe `exclusions.txt`.

## Installation
- Place tous les fichiers (`cmd.airmon-dos.sh`, `exclusions.txt`, `standard-oui.ieee`) dans un même dossier, par exemple `~/Security/airodump-dos`.
- Rends le script exécutable : `chmod +x cmd.airmon-dos.sh`.
- Lance le script avec : `./cmd.airmon-dos.sh [interface] [durée_scan] [intervalle_dos] [nombre_paquets]`.

## Logs
- Les logs sont sauvegardés automatiquement dans le sous-dossier `logs/`.

## Exclusion
- Les MAC et BSSID à exclure doivent être listés dans `exclusions.txt`, un par ligne, avec un commentaire optionnel.

## Fichier OUI
- Le fichier `standard-oui.ieee` permet de faire un lookup sur les MAC pour connaître les fabricants.

## Exemple
```bash
./cmd.airmon-dos.sh wlan1 600 30 5
