sudo systemctl restart iptables-fw.service 

sudo iptables -L


sleep 5

