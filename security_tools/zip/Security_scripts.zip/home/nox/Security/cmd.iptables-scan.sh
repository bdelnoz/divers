#!/bin/bash
# Script iptables pour autoriser uniquement le trafic Nmap/Zenmap sortant, avec résolution DNS complète

# Vider les règles existantes
iptables -F
iptables -X
iptables -Z

# Politique par défaut : DROP pour INPUT, OUTPUT, FORWARD
iptables -P INPUT DROP
iptables -P OUTPUT DROP
iptables -P FORWARD DROP

# Autoriser la loopback
iptables -A INPUT -i lo -j ACCEPT
iptables -A OUTPUT -o lo -j ACCEPT

# Autoriser les paquets établis et relatifs
iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT

# Autoriser le trafic sortant TCP et UDP (pour Nmap scans)
iptables -A OUTPUT -p tcp -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
iptables -A OUTPUT -p udp -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT

# Autoriser les réponses entrantes sur TCP et UDP pour connexions établies
iptables -A INPUT -p tcp -m conntrack --ctstate ESTABLISHED -j ACCEPT
iptables -A INPUT -p udp -m conntrack --ctstate ESTABLISHED -j ACCEPT

# Autoriser DNS (UDP 53 et TCP 53) pour résolution de noms
iptables -A OUTPUT -p udp --dport 53 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
iptables -A INPUT -p udp --sport 53 -m conntrack --ctstate ESTABLISHED -j ACCEPT
iptables -A OUTPUT -p tcp --dport 53 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
iptables -A INPUT -p tcp --sport 53 -m conntrack --ctstate ESTABLISHED -j ACCEPT

# Autoriser ICMP (ping)
iptables -A INPUT -p icmp -j ACCEPT
iptables -A OUTPUT -p icmp -j ACCEPT



iptables -L
sleep 5 

