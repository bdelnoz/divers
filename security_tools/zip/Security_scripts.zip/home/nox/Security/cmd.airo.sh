cd ~/Security/airodump-sniff/

sudo airodump-ng --gpsd --showack --real-time    --manufacturer   --uptime --beacons -b abg --beacons  --write sniff-airodump  --output-format csv  wlan1

sudo chown nox:nox /home/nox/Security/airodump-sniff/*.*
ls -lrt /home/nox/Security/airodump-sniff/*.*



sleep 5
